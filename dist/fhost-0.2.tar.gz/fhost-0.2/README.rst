fhost
=====

A python module that allows you to create, list, and modify local hosts file entries.

`Learn more <http://repejota.github.com/fhost>`_
